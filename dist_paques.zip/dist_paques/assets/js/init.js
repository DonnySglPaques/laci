$(function () {
    $('[data-toggle="popover"]').popover({
        trigger : 'hover'
    });

    $('[data-toggle="tooltip"]').tooltip({
        trigger : 'hover'
    });

    $.each($('.menu-toggle-close.toggled'), function(i, val) {
        $(val).next().slideToggle(0);
    });

    $('.menu-toggle-close').on('click', function(e) {
		// alert('tes')
            var $this = $(this);
            var $content = $this.next();

            if ($($this.parents('ul')[0]).hasClass('list')) {
                var $not = $(e.target).hasClass('menu-toggle-close') ? e.target : $(e.target).parents('.menu-toggle-close');

                $.each($('.menu-toggle-close.toggled').not($not).next(), function(i, val) {
                    if ($(val).is(':visible')) {
                        $(val).prev().toggleClass('toggled');
                        $(val).slideUp();
                    }
                });
            }

            $this.toggleClass('toggled');
            $content.slideToggle(320);
    });
    // setTimeout(function(){
    //     let rocketChatWidget = document.getElementsByClassName('rocketchat-widget')[0];
    //     rocketChatWidget.style.left = 0;
    //     rocketChatWidget.style.right = 'auto';
    //     rocketChatWidget.style.maxWidth = '295px';
    //     rocketChatWidget.style.maxHeight = '65vh';
    // }, 1000);

});

