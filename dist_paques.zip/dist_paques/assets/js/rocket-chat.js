$(function() {

	var rockectChatFuncInterval = setInterval(setRocketChatAlign, 500);
	function setRocketChatAlign() {
		let rocketChatWidget = document.getElementsByClassName('rocketchat-widget')[0];
		if (rocketChatWidget !== undefined) {
			rocketChatWidget.style.left = 0;
			rocketChatWidget.style.right = 'auto';
			rocketChatWidget.style.maxWidth = '295px';
			rocketChatWidget.style.maxHeight = '65vh';
			stopInterval();
		}
	}

	function stopInterval() {
		clearInterval(rockectChatFuncInterval);
	}

})
